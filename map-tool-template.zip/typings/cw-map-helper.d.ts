/// <reference types="arcgis-js-api" />
import { ICwData } from './data';
import { IUtilities } from './utilities';
import { IInternalMap, IQueryLayerInfo } from "./internal-map";
import { MapEvents } from "./cw-map";
import * as CoreTypes from 'cw-isdk/core';
import esri = __esri;
export { MapEvents } from "./cw-map";
export interface ICwMapHelper {
    bookmarks: {
        deleteBookmarks(bookmarkIds: Array<number>): Promise<Array<number>>;
        deleteScales(scaleIds: Array<number>): Promise<Array<number>>;
        getBookmarks(): Promise<Array<CoreTypes.UserMapExtent>>;
        getScales(): Promise<Array<CoreTypes.UserMapScale>>;
        saveBookmark(bookmark: CoreTypes.UserMapExtent): Promise<CoreTypes.UserMapExtent>;
        saveScale(scale: CoreTypes.UserMapScale): Promise<CoreTypes.UserMapScale>;
    };
    cwWkid: {
        getCwWkid(): number;
    };
    events: {
        fireEvent(name: MapEvents, details: any): void;
    };
    geocode: {
        addGeocodeCandidatePins(candidates: {
            x: number;
            y: number;
            id: number;
        }[]): void;
        geocode(address: string, city?: string, state?: string, zipCode?: string): Promise<CoreTypes.GeocodeResult[]>;
        getGeocodeServices(): CoreTypes.SimpleGisServiceInfo[];
        getGeocodeServerInfo(serviceId: number): Promise<CoreTypes.GeocodeServerConfiguration>;
        highlightGeocodeCandidatePin(id: number): void;
        removeGeocodeCandidatePins(): void;
        reverseGeocode(x: number, y: number): Promise<CoreTypes.GeocodeResult>;
    };
    geometry: {
        getService(): esri.GeometryService;
        projectGeometry(geometry: esri.Geometry[], sp: esri.SpatialReference): Promise<esri.Geometry[]>;
    };
    layout: {
        addCss(filePath: string): void;
    };
    log: {
        logMessage(message: any): void;
    };
    map: {
        addLayer(layer: esri.Layer): void;
        addMapPin(x: number, y: number, center?: boolean, imageUrl?: string, width?: number, height?: number): void;
        centerOnXY(x: number, y: number): void;
        clearSelectedAssets(entityType?: string): void;
        getCurrentExtent(): esri.Extent;
        getFeatureLayerViewGraphics(layer: esri.FeatureLayer, query?: esri.Query): Promise<esri.Graphic[]>;
        getGraphicsLayerViewGraphics(layer: esri.GraphicsLayer): Promise<esri.Graphic[]>;
        getMap(): esri.Map;
        getMapView(): esri.MapView | esri.SceneView;
        getSelectableLayers(): IQueryLayerInfo[];
        removeLayer(layerId: string): void;
        removeMapPins(): void;
        selectAssets(query: esri.Query, layerInfos?: IQueryLayerInfo[], mode?: string): void;
        setMapExtent(geometry: esri.Geometry[]): void;
        setSelectableLayer(selectedLayer: IQueryLayerInfo, selectable: boolean): void;
        zoomToFullExtent(): void;
    };
    printing: {
        getPrintTask(): esri.PrintTask;
    };
    routing: {
        getRouteTask(): esri.RouteTask;
    };
    site: {
        baseUrl(): string;
    };
    user: {
        getCurrentApp(): string;
        getCurrentAppConfig(): any;
        getCurrentUser(): CoreTypes.CWUser;
    };
}
export declare class CwMapHelper implements ICwMapHelper {
    private _utilities;
    private _data;
    private _map;
    private _user;
    private _userPrefs;
    private _eventAction;
    constructor(data: ICwData, utilities: IUtilities, map: IInternalMap, user: CoreTypes.CWUser, userPrefs: CoreTypes.UserPreferences, events: Function);
    bookmarks: {
        deleteBookmarks: (bookmarkIds: number[]) => Promise<number[]>;
        deleteScales: (scaleIds: number[]) => Promise<number[]>;
        getBookmarks: () => Promise<CoreTypes.UserMapExtent[]>;
        getScales: () => Promise<CoreTypes.UserMapScale[]>;
        saveBookmark: (bookmark: CoreTypes.UserMapExtent) => Promise<CoreTypes.UserMapExtent>;
        saveScale: (scale: CoreTypes.UserMapScale) => Promise<CoreTypes.UserMapScale>;
    };
    cwWkid: {
        getCwWkid: () => number;
    };
    events: {
        fireEvent: (name: MapEvents, details: any) => any;
    };
    geocode: {
        addGeocodeCandidatePins: (candidates: {
            x: number;
            y: number;
            id: number;
        }[]) => void;
        geocode: (address: string, city?: string, state?: string, zipCode?: string) => Promise<CoreTypes.GeocodeResult[]>;
        getGeocodeServerInfo: (serviceId: number) => Promise<CoreTypes.GeocodeServerConfiguration>;
        getGeocodeServices: () => CoreTypes.SimpleGisServiceInfo[];
        highlightGeocodeCandidatePin: (id: number) => void;
        removeGeocodeCandidatePins: () => void;
        reverseGeocode: (x: number, y: number) => Promise<CoreTypes.GeocodeResult>;
    };
    geometry: {
        getService: () => esri.GeometryService;
        projectGeometry: (geometry: esri.Geometry[], sp: esri.SpatialReference) => Promise<esri.Geometry[]>;
    };
    layout: {
        addCss: (filePath: string) => void;
    };
    log: {
        logMessage: (message: any) => void;
    };
    map: {
        addLayer: (layer: esri.Layer) => void;
        addMapPin: (x: number, y: number, center?: boolean, imageUrl?: string, width?: number, height?: number) => void;
        centerOnXY: (x: number, y: number) => void;
        clearSelectedAssets: (entityType?: string) => void;
        getCurrentExtent: () => esri.Extent;
        getFeatureLayerViewGraphics: (layer: esri.FeatureLayer, query?: esri.Query) => Promise<esri.Graphic[]>;
        getGraphicsLayerViewGraphics: (layer: esri.GraphicsLayer) => Promise<esri.Graphic[]>;
        getMap: () => esri.Map;
        getMapView: () => esri.MapView | esri.SceneView;
        getSelectableLayers: () => IQueryLayerInfo[];
        removeLayer: (layerId: string) => void;
        removeMapPins: () => void;
        selectAssets: (query: esri.Query, layerInfos?: IQueryLayerInfo[], mode?: string) => void;
        setMapExtent: (geometry: esri.Geometry[]) => Promise<any>;
        setSelectableLayer: (selectedLayer: IQueryLayerInfo, selectable: boolean) => void;
        zoomToFullExtent: () => void;
    };
    printing: {
        getPrintTask: () => esri.PrintTask;
    };
    routing: {
        getRouteTask: () => esri.RouteTask;
    };
    site: {
        baseUrl: () => string;
    };
    user: {
        getCurrentApp: () => string;
        getCurrentAppConfig: () => any;
        getCurrentUser: () => CoreTypes.CWUser;
    };
}
